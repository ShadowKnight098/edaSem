/**
 * ============================================================================
 * STEP 1: WEB CRAWLER (Node.js ESM + Microsoft Playwright)
 * ============================================================================
 * Seminar Topic: Automated Headless Web Scraping with Pagination & Error Handling
 * Target Site  : https://books.toscrape.com/
 * Optional Alt : https://quotes.toscrape.com/
 * 
 * Run Command  : node 1_crawler.js
 * Output File  : books_dataset.csv (UTF-8 with BOM)
 * ============================================================================
 */

import { chromium } from 'playwright';
import fs from 'fs';
import path from 'path';

// --- Configuration ---
const BASE_URL = 'https://books.toscrape.com/catalogue/page-1.html';
const OUTPUT_FILE = path.resolve('books_dataset.csv');
const MAX_PAGES_TO_SCRAPE = 50; // Set to 3 for quick classroom demo, or 50 for all 1,000 books
const POLITE_DELAY_MS = 150;    // Respectful delay between page fetches

// Map word ratings in CSS class to numeric integer (1-5)
const RATING_MAP = {
  'one': 1,
  'two': 2,
  'three': 3,
  'four': 4,
  'five': 5
};

const sleep = (ms) => new Promise((resolve) => setTimeout(resolve, ms));

// Safe CSV escaping adhering to RFC 4180
function escapeCsv(value) {
  if (value === null || value === undefined) return '""';
  const str = String(value);
  if (str.includes(',') || str.includes('"') || str.includes('\n')) {
    return `"${str.replace(/"/g, '""')}"`;
  }
  return `"${str}"`;
}

async function runCrawler() {
  console.log('------------------------------------------------------------');
  console.log('  DataLab Live: Step 1 - Playwright Web Crawler');
  console.log('  Target: https://books.toscrape.com/');
  console.log('------------------------------------------------------------\n');

  const startTime = Date.now();
  let browser = null;
  const scrapedBooks = [];

  try {
    console.log('[1/4] Launching headless Chromium browser...');
    browser = await chromium.launch({ headless: true });
    const context = await browser.newContext({
      userAgent: 'DataLabSeminar/1.0 (Educational Scraping Demo)'
    });
    const page = await context.newPage();

    let currentUrl = BASE_URL;
    let pageCount = 1;

    console.log('[2/4] Starting automated pagination traversal...\n');

    while (currentUrl && pageCount <= MAX_PAGES_TO_SCRAPE) {
      console.log(`  [Page ${String(pageCount).padStart(2, ' ')}] Requesting: ${currentUrl}`);

      // Fetch with timeout protection
      await page.goto(currentUrl, { waitUntil: 'domcontentloaded', timeout: 30000 });

      // Locate all book cards on the current page
      const bookCards = page.locator('article.product_pod');
      const booksOnPage = await bookCards.count();

      for (let i = 0; i < booksOnPage; i++) {
        const card = bookCards.nth(i);

        // 1. Full Book Title (from 'title' attribute to prevent ellipsis truncation)
        let title = await card.locator('h3 a').getAttribute('title');
        if (!title) title = await card.locator('h3 a').innerText();
        title = title.trim();

        // 2. Numeric Price (clean currency symbols like '£')
        const rawPrice = await card.locator('.price_color').innerText();
        const price = parseFloat(rawPrice.replace(/[^0-9.]/g, ''));

        // 3. Star Rating (word -> 1 to 5 integer)
        const ratingClass = (await card.locator('.star-rating').getAttribute('class')) || '';
        const ratingWord = ratingClass
          .split(' ')
          .find((c) => c.toLowerCase() !== 'star-rating')
          ?.toLowerCase() || '';
        const rating = RATING_MAP[ratingWord] || 0;

        // 4. Availability
        const rawAvail = await card.locator('.availability').innerText();
        const availability = rawAvail.trim().replace(/\s+/g, ' ');

        scrapedBooks.push({ title, price, rating, availability });
      }

      console.log(`         ↳ Extracted ${booksOnPage} books (Total running: ${scrapedBooks.length})`);

      // Detect next pagination button (<li class="next"><a href="...">)
      const nextButton = page.locator('li.next a');
      if ((await nextButton.count()) > 0 && pageCount < MAX_PAGES_TO_SCRAPE) {
        const nextHref = await nextButton.getAttribute('href');
        // Resolve relative URL dynamically
        currentUrl = new URL(nextHref, currentUrl).href;
        pageCount++;
        await sleep(POLITE_DELAY_MS);
      } else {
        currentUrl = null;
      }
    }

    console.log(`\n[3/4] Exporting ${scrapedBooks.length} records to ${OUTPUT_FILE}...`);

    // Prepare CSV with UTF-8 BOM (\uFEFF) for Excel compatibility
    const header = ['title', 'price', 'rating', 'availability'].join(',');
    const rows = scrapedBooks.map((b) =>
      [escapeCsv(b.title), b.price.toFixed(2), b.rating, escapeCsv(b.availability)].join(',')
    );

    const csvContent = '\uFEFF' + [header, ...rows].join('\r\n');
    fs.writeFileSync(OUTPUT_FILE, csvContent, 'utf8');

    const elapsed = ((Date.now() - startTime) / 1000).toFixed(1);
    console.log(`[4/4] SUCCESS: Crawled ${scrapedBooks.length} books in ${elapsed}s!`);
    console.log(`      File saved: ${OUTPUT_FILE}\n`);

  } catch (error) {
    console.error('Fatal crawler error:', error);
    process.exit(1);
  } finally {
    if (browser) {
      await browser.close();
      console.log('✓ Headless browser closed cleanly.');
    }
  }
}

runCrawler();
